/**
 * Planilha do Resgate na Hora.
 * 1. Crie uma planilha no Google.
 * 2. Extensões → Apps Script. Cole este arquivo. Troque SPREADSHEET_ID.
 * 3. Implantar → Nova implantação → App da Web.
 *    Executar como: eu. Quem tem acesso: qualquer pessoa.
 * 4. Copie a URL terminada em /exec para a variável GOOGLE_SHEETS_WEBHOOK.
 */
var SPREADSHEET_ID = "COLE_O_ID_DA_PLANILHA";

function doPost(e) {
  var sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheets()[0];
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["Quando", "Nome", "WhatsApp", "Modelo", "Serviço", "Problema", "Localização"]);
  }
  var data = {};
  try {
    data = JSON.parse(e.postData.contents);
  } catch (err) {
    data = { problem: "pedido sem dados" };
  }
  sheet.appendRow([
    data.at || new Date().toISOString(),
    data.name || "",
    data.phone || "",
    data.model || "",
    data.service || "",
    data.problem || "",
    data.location || "",
  ]);
  return ContentService.createTextOutput("ok");
}
