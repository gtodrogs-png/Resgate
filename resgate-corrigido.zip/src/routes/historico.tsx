import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/shell";
import { formatWhen, readRescues, type RescueEntry } from "@/lib/rescue-history";

export const Route = createFileRoute("/historico")({ component: History });

function History() {
  const [items, setItems] = useState<RescueEntry[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setItems(readRescues());
    setReady(true);
  }, []);

  return (
    <Shell>
      <h1 className="font-display text-4xl font-bold tracking-tight uppercase">Últimos pedidos</h1>
      <p className="mt-1 text-sm text-mute">Só o que foi pedido neste celular. A lista completa fica na sua planilha.</p>

      {ready && items.length === 0 ? (
        <p className="mt-5 rounded-card border border-line bg-panel px-4 py-4 text-sm text-mute">
          Nenhum pedido neste aparelho ainda.
        </p>
      ) : null}

      <ul className="mt-4 grid gap-2">
        {items.map((item) => (
          <li key={item.id} className="rounded-card border border-line bg-panel px-4 py-3">
            <div className="flex items-start justify-between gap-3">
              <p className="font-semibold">{item.service}</p>
              <p className="shrink-0 text-xs text-mute">{formatWhen(item.at)}</p>
            </div>
            <p className="mt-1 text-sm text-mute">
              {item.model}
              {item.name ? ` · ${item.name}` : ""}
            </p>
            {item.problem ? <p className="mt-1 text-sm leading-relaxed">{item.problem}</p> : null}
          </li>
        ))}
      </ul>

      <Link
        to="/resgate"
        className="mt-5 flex min-h-12 items-center justify-center rounded-full bg-signal px-5 text-sm font-bold tracking-wide text-paper uppercase"
      >
        Novo resgate
      </Link>
    </Shell>
  );
}
