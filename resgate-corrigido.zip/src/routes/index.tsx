import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { MapPin, ShieldCheck, Timer, Wrench } from "lucide-react";
import { Shell } from "@/components/shell";
import { formatWhen, readRescues, type RescueEntry } from "@/lib/rescue-history";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [last, setLast] = useState<RescueEntry | null>(null);

  useEffect(() => {
    setLast(readRescues()[0] ?? null);
  }, []);

  return (
    <Shell>
      <section className="overflow-hidden rounded-card border border-line bg-panel">
        <img src="/logo.png" alt="Resgate na Hora — Quando a moto para, a gente chega." className="aspect-square w-full object-cover" />
        <div className="px-5 py-5">
          <p className="text-xs font-semibold tracking-[0.22em] text-signal-soft uppercase">TVS Sport KS e ESD</p>
          <h1 className="mt-2 font-display text-4xl leading-none font-bold tracking-tight uppercase">
            Quando a moto para, a gente chega.
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-mute">
            Suporte de rua particular. Rua, rodovia ou na sua casa. Deslocamento, peça e mão de obra já entram no valor.
          </p>
          <Link
            to="/resgate"
            className="mt-5 flex min-h-12 items-center justify-center rounded-full bg-signal px-5 text-sm font-bold tracking-wide text-paper uppercase"
          >
            Solicitar resgate
          </Link>
        </div>
      </section>

      <ul className="mt-4 grid grid-cols-3 gap-2">
        {[
          { icon: Timer, label: "No local", sub: "sem guincho" },
          { icon: Wrench, label: "Peça pronta", sub: "na hora" },
          { icon: MapPin, label: "GPS", sub: "local exato" },
        ].map((item) => (
          <li key={item.label} className="rounded-card border border-line bg-panel px-2 py-3 text-center">
            <item.icon className="mx-auto text-signal" size={18} />
            <p className="mt-1 text-sm font-semibold">{item.label}</p>
            <p className="text-[11px] text-mute">{item.sub}</p>
          </li>
        ))}
      </ul>

      <section className="mt-6">
        <div className="mb-2 flex items-end justify-between">
          <h2 className="font-display text-2xl font-bold tracking-wide uppercase">Mais pedidos</h2>
          <Link to="/servicos" className="text-sm text-signal-soft">
            Ver tudo
          </Link>
        </div>
        <div className="grid gap-2">
          {[
            ["Flange da coroa", "R$ 250", "Peça em falta no mercado. A gente leva."],
            ["Relação completa", "R$ 180", "Coroa, corrente e pinhão."],
            ["Revisão checkout", "R$ 380", "Freio, relação, óleo e luzes."],
          ].map(([name, price, note]) => (
            <Link
              key={name}
              to="/resgate"
              search={{ servico: name }}
              className="flex items-center justify-between gap-3 rounded-card border border-line bg-panel px-4 py-3"
            >
              <span>
                <span className="block font-semibold">{name}</span>
                <span className="text-xs text-mute">{note}</span>
              </span>
              <span className="font-display text-2xl font-bold text-signal-soft">{price}</span>
            </Link>
          ))}
        </div>
      </section>

      {last ? (
        <Link to="/historico" className="mt-4 block rounded-card border border-line bg-panel px-4 py-4">
          <p className="text-xs font-semibold tracking-[0.18em] text-signal-soft uppercase">Último serviço</p>
          <p className="mt-1 font-semibold">{last.service}</p>
          <p className="mt-1 text-sm text-mute">
            {last.model} · {formatWhen(last.at)}
          </p>
        </Link>
      ) : null}

      <Link
        to="/outros"
        className="mt-4 block rounded-card border border-line bg-panel px-4 py-4"
      >
        <p className="text-xs font-semibold tracking-[0.18em] text-signal-soft uppercase">Outros modelos</p>
        <p className="mt-1 font-semibold">Peça sob consulta</p>
        <p className="mt-1 text-sm leading-relaxed text-mute">
          CG, Factor e outras motos. No horário comercial, se faltar peça, o mecânico retira no fornecedor e vai até você.
        </p>
      </Link>

      <section className="mt-6 rounded-card border border-line bg-panel-2 p-4">
        <div className="flex gap-3">
          <ShieldCheck className="shrink-0 text-ok" size={20} />
          <div>
            <p className="font-semibold">Serviço particular e independente</p>
            <p className="mt-1 text-sm leading-relaxed text-mute">
              Não temos vínculo com locadora de motos. Área base: 25 km a partir de Diadema. Fora disso, R$ 1,00 por km.
            </p>
          </div>
        </div>
      </section>
    </Shell>
  );
}
