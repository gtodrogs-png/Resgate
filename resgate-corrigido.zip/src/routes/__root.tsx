import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Resgate na Hora";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "Suporte de rua para TVS Sport KS e ESD. Deslocamento, peça e mão de obra. Quando a moto para, a gente chega.",
      },
      { name: "theme-color", content: "#0c0c0e" },
      { property: "og:type", content: "website" },
      { property: "og:title", content: APP_NAME },
      {
        property: "og:description",
        content:
          "Suporte de rua para TVS Sport KS e ESD. Deslocamento, peça e mão de obra. Quando a moto para, a gente chega.",
      },
      { property: "og:url", content: "https://resgate-pied.vercel.app" },
      { property: "og:site_name", content: APP_NAME },
      {
        property: "og:image",
        content: "https://i.ibb.co/KpK1cLtm/file-000000001ce4820ead1877270b05ce21.png",
      },
      { property: "og:image:width", content: "1254" },
      { property: "og:image:height", content: "1254" },
      { name: "twitter:card", content: "summary_large_image" },
      {
        name: "twitter:image",
        content: "https://i.ibb.co/KpK1cLtm/file-000000001ce4820ead1877270b05ce21.png",
      },
    ],
    links: [
      { rel: "icon", type: "image/png", href: "/favicon-32.png" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/apple-touch-icon.png" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700;1,9..40,400&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
