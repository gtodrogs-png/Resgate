import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, PackageSearch, Store } from "lucide-react";
import { Shell } from "@/components/shell";
import { CONSULTA_HOURS } from "@/data/services";

export const Route = createFileRoute("/outros")({ component: OtherModels });

const steps = [
  {
    icon: PackageSearch,
    title: "Você pede no app",
    text: "Informa o modelo e o que quebrou. Vale CG 150, CG 160, Factor 125, Factor 150 ou outro modelo.",
  },
  {
    icon: Store,
    title: "Peça no fornecedor",
    text: `No horário comercial (${CONSULTA_HOURS}), se não tiver na pronta entrega, o mecânico retira a peça e segue até a moto.`,
  },
  {
    icon: Clock,
    title: "Fora do horário",
    text: "Loja de peça fechada: o atendimento fica para o próximo dia útil. O valor só fecha depois de confirmar a peça.",
  },
];

function OtherModels() {
  return (
    <Shell>
      <p className="text-xs font-semibold tracking-[0.22em] text-signal-soft uppercase">Expansão</p>
      <h1 className="mt-2 font-display text-4xl leading-none font-bold tracking-tight uppercase">Outros modelos</h1>
      <p className="mt-3 text-sm leading-relaxed text-mute">
        Peça sob consulta. A moto não precisa ser TVS Sport. O serviço continua no local: rua, rodovia ou na sua casa.
      </p>

      <ol className="mt-5 grid gap-2">
        {steps.map((step, index) => (
          <li key={step.title} className="rounded-card border border-line bg-panel p-4">
            <div className="flex gap-3">
              <step.icon className="mt-0.5 shrink-0 text-signal" size={18} />
              <div>
                <p className="text-xs font-semibold tracking-wide text-mute uppercase">0{index + 1}</p>
                <h2 className="font-semibold">{step.title}</h2>
                <p className="mt-1 text-sm leading-relaxed text-mute">{step.text}</p>
              </div>
            </div>
          </li>
        ))}
      </ol>

      <section className="mt-4 rounded-card border border-line bg-panel-2 p-4 text-sm leading-relaxed text-mute">
        Deslocamento, peça e mão de obra entram no valor. Saída mínima R$ 100. Serviço particular, sem vínculo com locadora.
      </section>

      <Link
        to="/resgate"
        search={{ servico: "Peça sob consulta" }}
        className="mt-5 flex min-h-12 items-center justify-center rounded-full bg-signal px-5 text-sm font-bold tracking-wide text-paper uppercase"
      >
        Solicitar peça sob consulta
      </Link>
    </Shell>
  );
}
