import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { services, type Service } from "@/data/services";

export const Route = createFileRoute("/servicos")({ component: Catalog });

const groups: { id: Service["group"] | "todos"; label: string }[] = [
  { id: "todos", label: "Todos" },
  { id: "urgente", label: "Urgente" },
  { id: "transmissao", label: "Relação" },
  { id: "freio", label: "Freio" },
  { id: "revisao", label: "Revisão" },
  { id: "peca", label: "Peças" },
  { id: "consulta", label: "Outros" },
];

function Catalog() {
  const [group, setGroup] = useState<(typeof groups)[number]["id"]>("todos");
  const list = services.filter((s) => group === "todos" || s.group === group);

  return (
    <Shell>
      <h1 className="font-display text-4xl font-bold tracking-tight uppercase">Catálogo</h1>
      <p className="mt-1 text-sm text-mute">Valores com deslocamento, peça e mão de obra.</p>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {groups.map((g) => (
          <button
            key={g.id}
            type="button"
            onClick={() => setGroup(g.id)}
            className={`shrink-0 rounded-full px-3 py-2 text-sm ${
              group === g.id ? "bg-signal text-paper" : "border border-line bg-panel text-mute"
            }`}
          >
            {g.label}
          </button>
        ))}
      </div>
      <ul className="mt-4 grid gap-2">
        {list.map((item) => (
          <li key={item.id} className="rounded-card border border-line bg-panel p-4">
            <div className="flex items-start justify-between gap-3">
              <h2 className="font-semibold">{item.name}</h2>
              <p className="font-display text-2xl leading-none font-bold text-signal-soft">{item.price}</p>
            </div>
            <p className="mt-1 text-sm leading-relaxed text-mute">{item.note}</p>
            <Link
              to="/resgate"
              search={{ servico: item.name }}
              className="mt-3 inline-flex min-h-10 items-center text-sm font-semibold text-signal-soft"
            >
              Pedir este serviço
            </Link>
          </li>
        ))}
      </ul>
    </Shell>
  );
}
