import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { LocateFixed, Navigation } from "lucide-react";
import { Shell } from "@/components/shell";
import { CONSULTA_HOURS, models, services, WHATSAPP, WHATSAPP_DISPLAY } from "@/data/services";
import { saveRescue } from "@/lib/rescue-history";
import { logRescueToSheet } from "@/lib/rescue-log";

type Search = { servico?: string };

export const Route = createFileRoute("/resgate")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    servico: typeof search.servico === "string" ? search.servico : undefined,
  }),
  component: Rescue,
});

type Gps = { lat: number; lng: number; accuracy: number } | null;

function Rescue() {
  const { servico } = Route.useSearch();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [model, setModel] = useState<(typeof models)[number]>("TVS Sport ESD");
  const [service, setService] = useState(servico ?? "Flange da coroa");
  const [problem, setProblem] = useState("");
  const [gps, setGps] = useState<Gps>(null);
  const [gpsError, setGpsError] = useState("");
  const [locating, setLocating] = useState(false);

  const maps = gps ? `https://maps.google.com/?q=${gps.lat},${gps.lng}` : "";

  const message = useMemo(() => {
    return [
      "*Solicitação de Resgate na Hora*",
      "",
      `*Nome:* ${name || "—"}`,
      `*WhatsApp:* ${phone || "—"}`,
      `*Modelo:* ${model}`,
      `*Serviço:* ${service}`,
      `*Problema:* ${problem || "—"}`,
      `*Localização:* ${maps || "não enviada"}`,
    ].join("\n");
  }, [name, phone, model, service, problem, maps]);

  function locate() {
    setGpsError("");
    if (!navigator.geolocation) {
      setGpsError("Este aparelho não liberou o GPS.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGps({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
          accuracy: Math.round(pos.coords.accuracy),
        });
        setLocating(false);
      },
      () => {
        setGpsError("Permita a localização para o resgate achar a moto.");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 },
    );
  }

  function send() {
    const entry = {
      id: crypto.randomUUID(),
      at: new Date().toISOString(),
      name: name.trim(),
      phone: phone.trim(),
      model,
      service,
      problem: problem.trim(),
      location: maps,
    };
    saveRescue(entry);
    void logRescueToSheet({ data: entry }).catch(() => undefined);
    const url = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  const ready = name.trim().length > 1 && service;

  return (
    <Shell>
      <h1 className="font-display text-4xl font-bold tracking-tight uppercase">Solicitar resgate</h1>
      <p className="mt-1 text-sm text-mute">O pedido abre no WhatsApp {WHATSAPP_DISPLAY}, já pronto.</p>

      <form
        className="mt-5 grid gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (ready) send();
        }}
      >
        <Field label="Seu nome">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={inputClass}
            placeholder="Como te chamar"
            autoComplete="name"
          />
        </Field>
        <Field label="Seu WhatsApp">
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className={inputClass}
            placeholder="(11) 90000-0000"
            inputMode="tel"
            autoComplete="tel"
          />
        </Field>
        <Field label="Modelo">
          <select value={model} onChange={(e) => setModel(e.target.value as (typeof models)[number])} className={inputClass}>
            {models.map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </Field>
        <Field label="Serviço">
          <select value={service} onChange={(e) => setService(e.target.value)} className={inputClass}>
            {services.map((s) => (
              <option key={s.id}>{s.name}</option>
            ))}
          </select>
        </Field>
        <Field label="O que aconteceu">
          <textarea
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            className={`${inputClass} min-h-24 resize-none`}
            placeholder="Corrente quebrou, flange solta, moto não anda..."
          />
        </Field>

        <button
          type="button"
          onClick={locate}
          className="flex min-h-12 items-center justify-center gap-2 rounded-full border border-signal bg-signal/15 text-sm font-semibold text-paper"
        >
          <LocateFixed size={18} />
          {locating ? "Buscando GPS..." : gps ? "Atualizar localização" : "Usar minha localização"}
        </button>
        {gps ? (
          <p className="rounded-card border border-ok/40 bg-ok/10 px-3 py-2 text-sm text-ok">
            GPS ok · precisão de {gps.accuracy} m
            <span className="mt-1 block break-all text-xs text-paper/80">{maps}</span>
          </p>
        ) : null}
        {gpsError ? <p className="text-sm text-signal-soft">{gpsError}</p> : null}

        <button
          type="submit"
          disabled={!ready}
          className="flex min-h-12 items-center justify-center gap-2 rounded-full bg-signal text-sm font-bold tracking-wide text-paper uppercase disabled:opacity-40"
        >
          <Navigation size={18} />
          Enviar no WhatsApp
        </button>
        <p className="text-center text-xs leading-relaxed text-mute">
          {service === "Peça sob consulta"
            ? `Peça sob consulta: no horário comercial (${CONSULTA_HOURS}) o mecânico pode passar no fornecedor antes de ir até a moto. Fora disso, fica para o próximo dia útil. O valor fecha depois da peça.`
            : "Saída mínima R$ 100. Raio de 25 km a partir de Diadema. Fora disso, R$ 1 por km. Serviço particular, sem vínculo com locadora."}
        </p>
      </form>
    </Shell>
  );
}

const inputClass =
  "w-full min-h-12 rounded-xl border border-line bg-panel px-3 text-paper outline-none focus:border-signal";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="font-medium text-mute">{label}</span>
      {children}
    </label>
  );
}
