export type Service = {
  id: string;
  name: string;
  price: string;
  note: string;
  group: "urgente" | "transmissao" | "freio" | "revisao" | "peca" | "consulta";
};

export const WHATSAPP = "5511968293697";
export const WHATSAPP_DISPLAY = "(11) 96829-3697";

export const services: Service[] = [
  {
    id: "saida",
    name: "Saída mínima",
    price: "R$ 100",
    note: "Deslocamento, peça e mão de obra no serviço pontual.",
    group: "urgente",
  },
  {
    id: "flange",
    name: "Flange da coroa",
    price: "R$ 250",
    note: "Com rolamento, prisioneiros, porcas, coxins e esticador esquerdo quando precisar.",
    group: "urgente",
  },
  {
    id: "relacao",
    name: "Relação completa",
    price: "R$ 180",
    note: "Coroa, corrente e pinhão. KS, ESD e também CG 150/160.",
    group: "transmissao",
  },
  {
    id: "corrente",
    name: "Corrente",
    price: "R$ 100",
    note: "Corrente quebrada ou perdida. Só o que quebrou.",
    group: "transmissao",
  },
  {
    id: "pinhao",
    name: "Pinhão",
    price: "R$ 100",
    note: "Pinhão novo com trava e parafusos.",
    group: "transmissao",
  },
  {
    id: "coroa",
    name: "Coroa",
    price: "R$ 100",
    note: "Troca da coroa. Corrente blindada pode precisar ir junto.",
    group: "transmissao",
  },
  {
    id: "checkout",
    name: "Revisão checkout",
    price: "R$ 380",
    note: "Freio dianteiro e traseiro, relação, óleo e luzes.",
    group: "revisao",
  },
  {
    id: "freio",
    name: "Freio dianteiro e traseiro",
    price: "R$ 150",
    note: "ESD: pastilha na frente. KS: lona na frente. Lona traseira nos dois.",
    group: "freio",
  },
  {
    id: "pastilha",
    name: "Pastilha dianteira ESD",
    price: "R$ 100",
    note: "Troca da pastilha do disco dianteiro.",
    group: "freio",
  },
  {
    id: "lona",
    name: "Lona traseira",
    price: "R$ 100",
    note: "KS e ESD. Limpeza do eixo e regulagem.",
    group: "freio",
  },
  {
    id: "cabo-ace",
    name: "Cabo de acelerador",
    price: "R$ 100",
    note: "Rompido ou mastigado.",
    group: "peca",
  },
  {
    id: "cabo-emb",
    name: "Cabo de embreagem",
    price: "R$ 100",
    note: "KS e ESD.",
    group: "peca",
  },
  {
    id: "cabo-freio",
    name: "Cabo de freio KS",
    price: "R$ 100",
    note: "Somente Sport KS.",
    group: "peca",
  },
  {
    id: "manete",
    name: "Manete",
    price: "a partir de R$ 100",
    note: "Embreagem KS/ESD R$ 100. Freio KS R$ 100. Freio ESD R$ 150.",
    group: "peca",
  },
  {
    id: "estribo",
    name: "Estribo completo",
    price: "R$ 300",
    note: "Com parafusos e borracha. Não desentortamos.",
    group: "peca",
  },
  {
    id: "miolo",
    name: "Miolo de ignição",
    price: "R$ 270",
    note: "Troca do conjunto. Não fazemos cópia de chave.",
    group: "peca",
  },
  {
    id: "oleo",
    name: "Troca de óleo",
    price: "R$ 100",
    note: "KS e ESD. Deslocamento e mão inclusos.",
    group: "revisao",
  },
  {
    id: "consulta",
    name: "Peça sob consulta",
    price: "A combinar",
    note: "Outros modelos. No horário comercial, se não tiver a peça, o mecânico retira no fornecedor e vai até a moto.",
    group: "consulta",
  },
];

export const models = [
  "TVS Sport KS",
  "TVS Sport ESD",
  "CG 150",
  "CG 160",
  "Yamaha Factor 125",
  "Yamaha Factor 150",
  "Outro modelo",
] as const;

export const CONSULTA_HOURS = "segunda a sexta, 8h às 18h";
