export function Mark({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <circle cx="32" cy="32" r="30" fill="currentColor" className="text-signal" />
      <circle cx="32" cy="32" r="22" fill="none" stroke="currentColor" className="text-paper" strokeWidth="2.4" />
      <path
        d="M32 14v6M32 44v6M14 32h6M44 32h6M19.5 19.5l4.2 4.2M40.3 40.3l4.2 4.2M19.5 44.5l4.2-4.2"
        stroke="currentColor"
        className="text-paper"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path d="M32 32 L44 22" stroke="currentColor" className="text-paper" strokeWidth="2.6" strokeLinecap="round" />
      <circle cx="32" cy="32" r="3" className="fill-paper" />
      <path
        d="M46 40c6 2 10 7 10 12h-8c0-3-2-6-5-7"
        fill="none"
        stroke="currentColor"
        className="text-paper"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );
}
