import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Wrench, Siren } from "lucide-react";

const tabs = [
  { to: "/", label: "Início", icon: Home },
  { to: "/servicos", label: "Serviços", icon: Wrench },
  { to: "/resgate", label: "Resgate", icon: Siren },
] as const;

export function Shell({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col bg-ink text-paper">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-line bg-ink/95 px-4 py-2.5 backdrop-blur">
        <Link to="/" className="flex items-center gap-2.5">
          <img src="/logo.png" alt="" className="h-11 w-11 rounded-full object-cover ring-2 ring-signal" />
          <div className="leading-none">
            <p className="font-display text-xl font-bold tracking-wide uppercase">Resgate na Hora</p>
            <p className="text-[11px] tracking-[0.16em] text-mute uppercase">Suporte de rua</p>
          </div>
        </Link>
        <span className="rounded-full border border-signal/40 bg-signal/15 px-2.5 py-1 text-[11px] font-semibold tracking-wide text-signal-soft uppercase">
          24h
        </span>
      </header>
      <main className="flex-1 px-4 pb-28 pt-5">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-20 mx-auto w-full max-w-lg border-t border-line bg-ink/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur">
        <ul className="grid grid-cols-3 gap-1">
          {tabs.map((tab) => {
            const active = path === tab.to;
            const Icon = tab.icon;
            return (
              <li key={tab.to}>
                <Link
                  to={tab.to}
                  className={`flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-xl text-xs ${
                    active ? "bg-signal text-paper" : "text-mute"
                  }`}
                >
                  <Icon size={18} strokeWidth={2.2} />
                  {tab.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
