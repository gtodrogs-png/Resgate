export type RescueEntry = {
  id: string;
  at: string;
  name: string;
  phone: string;
  model: string;
  service: string;
  problem: string;
  location: string;
};

const KEY = "resgate-na-hora-pedidos";
const MAX = 8;

export function readRescues(): RescueEntry[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item.id === "string" && typeof item.at === "string");
  } catch {
    return [];
  }
}

export function saveRescue(entry: RescueEntry) {
  const next = [entry, ...readRescues().filter((item) => item.id !== entry.id)].slice(0, MAX);
  localStorage.setItem(KEY, JSON.stringify(next));
}

export function formatWhen(iso: string) {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(iso));
}
