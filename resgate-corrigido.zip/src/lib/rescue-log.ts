import { createServerFn } from "@tanstack/react-start";
import type { RescueEntry } from "@/lib/rescue-history";

function clean(value: unknown, max: number) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export const logRescueToSheet = createServerFn({ method: "POST" })
  .validator((input: RescueEntry) => ({
    id: clean(input?.id, 40),
    at: clean(input?.at, 40),
    name: clean(input?.name, 80),
    phone: clean(input?.phone, 30),
    model: clean(input?.model, 40),
    service: clean(input?.service, 80),
    problem: clean(input?.problem, 400),
    location: clean(input?.location, 200),
  }))
  .handler(async ({ data }) => {
    const { env } = await import("@/lib/env.server");
    const url = env("GOOGLE_SHEETS_WEBHOOK");
    if (!url) return { ok: false, skipped: true };
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(data),
      redirect: "follow",
    });
    return { ok: res.ok, skipped: false };
  });
