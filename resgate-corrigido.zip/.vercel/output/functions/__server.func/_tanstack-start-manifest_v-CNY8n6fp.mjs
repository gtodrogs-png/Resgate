//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CNY8n6fp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/historico",
			"/outros",
			"/resgate",
			"/servicos"
		],
		preloads: ["/assets/index-DTaeebOg.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DTaeebOg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C_9WXk2D.js",
			"/assets/shell-B1OFk9YD.js",
			"/assets/rescue-history-R563qqt8.js"
		]
	},
	"/historico": {
		filePath: "/workspace/src/routes/historico.tsx",
		children: void 0,
		preloads: [
			"/assets/historico-CcmWKaiv.js",
			"/assets/shell-B1OFk9YD.js",
			"/assets/rescue-history-R563qqt8.js"
		]
	},
	"/outros": {
		filePath: "/workspace/src/routes/outros.tsx",
		children: void 0,
		preloads: [
			"/assets/outros-DxCwUfub.js",
			"/assets/shell-B1OFk9YD.js",
			"/assets/services-C5JjVukb.js"
		]
	},
	"/resgate": {
		filePath: "/workspace/src/routes/resgate.tsx",
		children: void 0,
		preloads: [
			"/assets/resgate-CvRk_lWO.js",
			"/assets/shell-B1OFk9YD.js",
			"/assets/rescue-history-R563qqt8.js",
			"/assets/services-C5JjVukb.js"
		]
	},
	"/servicos": {
		filePath: "/workspace/src/routes/servicos.tsx",
		children: void 0,
		preloads: [
			"/assets/servicos-lsz009Tt.js",
			"/assets/shell-B1OFk9YD.js",
			"/assets/services-C5JjVukb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
