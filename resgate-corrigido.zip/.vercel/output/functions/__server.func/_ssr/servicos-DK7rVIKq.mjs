import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./shell-DAxfaJcw.mjs";
import { a as services } from "./services-BgH37Pjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/servicos-DK7rVIKq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var groups = [
	{
		id: "todos",
		label: "Todos"
	},
	{
		id: "urgente",
		label: "Urgente"
	},
	{
		id: "transmissao",
		label: "Relação"
	},
	{
		id: "freio",
		label: "Freio"
	},
	{
		id: "revisao",
		label: "Revisão"
	},
	{
		id: "peca",
		label: "Peças"
	},
	{
		id: "consulta",
		label: "Outros"
	}
];
function Catalog() {
	const [group, setGroup] = (0, import_react.useState)("todos");
	const list = services.filter((s) => group === "todos" || s.group === group);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-bold tracking-tight uppercase",
			children: "Catálogo"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-mute",
			children: "Valores com deslocamento, peça e mão de obra."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex gap-2 overflow-x-auto pb-1",
			children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setGroup(g.id),
				className: `shrink-0 rounded-full px-3 py-2 text-sm ${group === g.id ? "bg-signal text-paper" : "border border-line bg-panel text-mute"}`,
				children: g.label
			}, g.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-2",
			children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-none font-bold text-signal-soft",
							children: item.price
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-mute",
						children: item.note
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/resgate",
						search: { servico: item.name },
						className: "mt-3 inline-flex min-h-10 items-center text-sm font-semibold text-signal-soft",
						children: "Pedir este serviço"
					})
				]
			}, item.id))
		})
	] });
}
//#endregion
export { Catalog as component };
