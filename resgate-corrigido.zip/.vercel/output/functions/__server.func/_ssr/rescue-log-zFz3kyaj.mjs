import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rescue-log-zFz3kyaj.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function clean(value, max) {
	return typeof value === "string" ? value.trim().slice(0, max) : "";
}
var logRescueToSheet_createServerFn_handler = createServerRpc({
	id: "67759fade2b3b85aab2bf00d58b618c40fcf7e33f87a550899314cfed5218938",
	name: "logRescueToSheet",
	filename: "src/lib/rescue-log.ts"
}, (opts) => logRescueToSheet.__executeServer(opts));
var logRescueToSheet = createServerFn({ method: "POST" }).validator((input) => ({
	id: clean(input?.id, 40),
	at: clean(input?.at, 40),
	name: clean(input?.name, 80),
	phone: clean(input?.phone, 30),
	model: clean(input?.model, 40),
	service: clean(input?.service, 80),
	problem: clean(input?.problem, 400),
	location: clean(input?.location, 200)
})).handler(logRescueToSheet_createServerFn_handler, async ({ data }) => {
	const { env } = await import("./env.server-DRkkE6Ij.mjs");
	const url = env("GOOGLE_SHEETS_WEBHOOK");
	if (!url) return {
		ok: false,
		skipped: true
	};
	return {
		ok: (await fetch(url, {
			method: "POST",
			headers: { "Content-Type": "text/plain;charset=utf-8" },
			body: JSON.stringify(data),
			redirect: "follow"
		})).ok,
		skipped: false
	};
});
//#endregion
export { logRescueToSheet_createServerFn_handler };
