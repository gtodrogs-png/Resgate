import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Clock, i as Store, s as PackageSearch } from "../_libs/lucide-react.mjs";
import { t as Shell } from "./shell-DAxfaJcw.mjs";
import { t as CONSULTA_HOURS } from "./services-BgH37Pjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/outros-BwFm672I.js
var import_jsx_runtime = require_jsx_runtime();
var steps = [
	{
		icon: PackageSearch,
		title: "Você pede no app",
		text: "Informa o modelo e o que quebrou. Vale CG 150, CG 160, Factor 125, Factor 150 ou outro modelo."
	},
	{
		icon: Store,
		title: "Peça no fornecedor",
		text: `No horário comercial (${CONSULTA_HOURS}), se não tiver na pronta entrega, o mecânico retira a peça e segue até a moto.`
	},
	{
		icon: Clock,
		title: "Fora do horário",
		text: "Loja de peça fechada: o atendimento fica para o próximo dia útil. O valor só fecha depois de confirmar a peça."
	}
];
function OtherModels() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-[0.22em] text-signal-soft uppercase",
			children: "Expansão"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl leading-none font-bold tracking-tight uppercase",
			children: "Outros modelos"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-relaxed text-mute",
			children: "Peça sob consulta. A moto não precisa ser TVS Sport. O serviço continua no local: rua, rodovia ou na sua casa."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-5 grid gap-2",
			children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-card border border-line bg-panel p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(step.icon, {
						className: "mt-0.5 shrink-0 text-signal",
						size: 18
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold tracking-wide text-mute uppercase",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-mute",
							children: step.text
						})
					] })]
				})
			}, step.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mt-4 rounded-card border border-line bg-panel-2 p-4 text-sm leading-relaxed text-mute",
			children: "Deslocamento, peça e mão de obra entram no valor. Saída mínima R$ 100. Serviço particular, sem vínculo com locadora."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/resgate",
			search: { servico: "Peça sob consulta" },
			className: "mt-5 flex min-h-12 items-center justify-center rounded-full bg-signal px-5 text-sm font-bold tracking-wide text-paper uppercase",
			children: "Solicitar peça sob consulta"
		})
	] });
}
//#endregion
export { OtherModels as component };
