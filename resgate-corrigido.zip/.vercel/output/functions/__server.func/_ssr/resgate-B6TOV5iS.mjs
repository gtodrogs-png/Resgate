import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Navigation, u as LocateFixed } from "../_libs/lucide-react.mjs";
import { t as Shell } from "./shell-DAxfaJcw.mjs";
import { r as saveRescue } from "./rescue-history-BRfL634_.mjs";
import { a as services, i as models, n as WHATSAPP, r as WHATSAPP_DISPLAY, t as CONSULTA_HOURS } from "./services-BgH37Pjs.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as Route$1 } from "./router-DzX_WDn_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resgate-B6TOV5iS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function clean(value, max) {
	return typeof value === "string" ? value.trim().slice(0, max) : "";
}
var logRescueToSheet = createServerFn({ method: "POST" }).validator((input) => ({
	id: clean(input?.id, 40),
	at: clean(input?.at, 40),
	name: clean(input?.name, 80),
	phone: clean(input?.phone, 30),
	model: clean(input?.model, 40),
	service: clean(input?.service, 80),
	problem: clean(input?.problem, 400),
	location: clean(input?.location, 200)
})).handler(createSsrRpc("67759fade2b3b85aab2bf00d58b618c40fcf7e33f87a550899314cfed5218938"));
function Rescue() {
	const { servico } = Route$1.useSearch();
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [model, setModel] = (0, import_react.useState)("TVS Sport ESD");
	const [service, setService] = (0, import_react.useState)(servico ?? "Flange da coroa");
	const [problem, setProblem] = (0, import_react.useState)("");
	const [gps, setGps] = (0, import_react.useState)(null);
	const [gpsError, setGpsError] = (0, import_react.useState)("");
	const [locating, setLocating] = (0, import_react.useState)(false);
	const maps = gps ? `https://maps.google.com/?q=${gps.lat},${gps.lng}` : "";
	const message = (0, import_react.useMemo)(() => {
		return [
			"*Solicitação de Resgate na Hora*",
			"",
			`*Nome:* ${name || "—"}`,
			`*WhatsApp:* ${phone || "—"}`,
			`*Modelo:* ${model}`,
			`*Serviço:* ${service}`,
			`*Problema:* ${problem || "—"}`,
			`*Localização:* ${maps || "não enviada"}`
		].join("\n");
	}, [
		name,
		phone,
		model,
		service,
		problem,
		maps
	]);
	function locate() {
		setGpsError("");
		if (!navigator.geolocation) {
			setGpsError("Este aparelho não liberou o GPS.");
			return;
		}
		setLocating(true);
		navigator.geolocation.getCurrentPosition((pos) => {
			setGps({
				lat: Number(pos.coords.latitude.toFixed(6)),
				lng: Number(pos.coords.longitude.toFixed(6)),
				accuracy: Math.round(pos.coords.accuracy)
			});
			setLocating(false);
		}, () => {
			setGpsError("Permita a localização para o resgate achar a moto.");
			setLocating(false);
		}, {
			enableHighAccuracy: true,
			timeout: 12e3,
			maximumAge: 0
		});
	}
	function send() {
		const entry = {
			id: crypto.randomUUID(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			name: name.trim(),
			phone: phone.trim(),
			model,
			service,
			problem: problem.trim(),
			location: maps
		};
		saveRescue(entry);
		logRescueToSheet({ data: entry }).catch(() => void 0);
		const url = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`;
		window.open(url, "_blank", "noopener,noreferrer");
	}
	const ready = name.trim().length > 1 && service;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-bold tracking-tight uppercase",
			children: "Solicitar resgate"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-mute",
			children: [
				"O pedido abre no WhatsApp ",
				WHATSAPP_DISPLAY,
				", já pronto."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				if (ready) send();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Seu nome",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						className: inputClass,
						placeholder: "Como te chamar",
						autoComplete: "name"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Seu WhatsApp",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						className: inputClass,
						placeholder: "(11) 90000-0000",
						inputMode: "tel",
						autoComplete: "tel"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Modelo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: model,
						onChange: (e) => setModel(e.target.value),
						className: inputClass,
						children: models.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: m }, m))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Serviço",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: service,
						onChange: (e) => setService(e.target.value),
						className: inputClass,
						children: services.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s.name }, s.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "O que aconteceu",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: problem,
						onChange: (e) => setProblem(e.target.value),
						className: `${inputClass} min-h-24 resize-none`,
						placeholder: "Corrente quebrou, flange solta, moto não anda..."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: locate,
					className: "flex min-h-12 items-center justify-center gap-2 rounded-full border border-signal bg-signal/15 text-sm font-semibold text-paper",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, { size: 18 }), locating ? "Buscando GPS..." : gps ? "Atualizar localização" : "Usar minha localização"]
				}),
				gps ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-card border border-ok/40 bg-ok/10 px-3 py-2 text-sm text-ok",
					children: [
						"GPS ok · precisão de ",
						gps.accuracy,
						" m",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block break-all text-xs text-paper/80",
							children: maps
						})
					]
				}) : null,
				gpsError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-signal-soft",
					children: gpsError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "submit",
					disabled: !ready,
					className: "flex min-h-12 items-center justify-center gap-2 rounded-full bg-signal text-sm font-bold tracking-wide text-paper uppercase disabled:opacity-40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { size: 18 }), "Enviar no WhatsApp"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs leading-relaxed text-mute",
					children: service === "Peça sob consulta" ? `Peça sob consulta: no horário comercial (${CONSULTA_HOURS}) o mecânico pode passar no fornecedor antes de ir até a moto. Fora disso, fica para o próximo dia útil. O valor fecha depois da peça.` : "Saída mínima R$ 100. Raio de 25 km a partir de Diadema. Fora disso, R$ 1 por km. Serviço particular, sem vínculo com locadora."
				})
			]
		})
	] });
}
var inputClass = "w-full min-h-12 rounded-xl border border-line bg-panel px-3 text-paper outline-none focus:border-signal";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium text-mute",
			children: label
		}), children]
	});
}
//#endregion
export { Rescue as component };
