//#region node_modules/.nitro/vite/services/ssr/assets/rescue-history-BRfL634_.js
var KEY = "resgate-na-hora-pedidos";
var MAX = 8;
function readRescues() {
	if (typeof localStorage === "undefined") return [];
	try {
		const parsed = JSON.parse(localStorage.getItem(KEY) ?? "[]");
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => item && typeof item.id === "string" && typeof item.at === "string");
	} catch {
		return [];
	}
}
function saveRescue(entry) {
	const next = [entry, ...readRescues().filter((item) => item.id !== entry.id)].slice(0, MAX);
	localStorage.setItem(KEY, JSON.stringify(next));
}
function formatWhen(iso) {
	return new Intl.DateTimeFormat("pt-BR", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}).format(new Date(iso));
}
//#endregion
export { readRescues as n, saveRescue as r, formatWhen as t };
