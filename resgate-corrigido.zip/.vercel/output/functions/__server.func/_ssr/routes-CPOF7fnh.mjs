import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as MapPin, o as ShieldCheck, r as Timer, t as Wrench } from "../_libs/lucide-react.mjs";
import { t as Shell } from "./shell-DAxfaJcw.mjs";
import { n as readRescues, t as formatWhen } from "./rescue-history-BRfL634_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CPOF7fnh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const [last, setLast] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setLast(readRescues()[0] ?? null);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "overflow-hidden rounded-card border border-line bg-panel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/logo.png",
				alt: "Resgate na Hora — Quando a moto para, a gente chega.",
				className: "aspect-square w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.22em] text-signal-soft uppercase",
						children: "TVS Sport KS e ESD"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl leading-none font-bold tracking-tight uppercase",
						children: "Quando a moto para, a gente chega."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-mute",
						children: "Suporte de rua particular. Rua, rodovia ou na sua casa. Deslocamento, peça e mão de obra já entram no valor."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/resgate",
						className: "mt-5 flex min-h-12 items-center justify-center rounded-full bg-signal px-5 text-sm font-bold tracking-wide text-paper uppercase",
						children: "Solicitar resgate"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid grid-cols-3 gap-2",
			children: [
				{
					icon: Timer,
					label: "No local",
					sub: "sem guincho"
				},
				{
					icon: Wrench,
					label: "Peça pronta",
					sub: "na hora"
				},
				{
					icon: MapPin,
					label: "GPS",
					sub: "local exato"
				}
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-card border border-line bg-panel px-2 py-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
						className: "mx-auto text-signal",
						size: 18
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm font-semibold",
						children: item.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-mute",
						children: item.sub
					})
				]
			}, item.label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-bold tracking-wide uppercase",
					children: "Mais pedidos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/servicos",
					className: "text-sm text-signal-soft",
					children: "Ver tudo"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: [
					[
						"Flange da coroa",
						"R$ 250",
						"Peça em falta no mercado. A gente leva."
					],
					[
						"Relação completa",
						"R$ 180",
						"Coroa, corrente e pinhão."
					],
					[
						"Revisão checkout",
						"R$ 380",
						"Freio, relação, óleo e luzes."
					]
				].map(([name, price, note]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/resgate",
					search: { servico: name },
					className: "flex items-center justify-between gap-3 rounded-card border border-line bg-panel px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-semibold",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-mute",
						children: note
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl font-bold text-signal-soft",
						children: price
					})]
				}, name))
			})]
		}),
		last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/historico",
			className: "mt-4 block rounded-card border border-line bg-panel px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-signal-soft uppercase",
					children: "Último serviço"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-semibold",
					children: last.service
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-mute",
					children: [
						last.model,
						" · ",
						formatWhen(last.at)
					]
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/outros",
			className: "mt-4 block rounded-card border border-line bg-panel px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-signal-soft uppercase",
					children: "Outros modelos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-semibold",
					children: "Peça sob consulta"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-mute",
					children: "CG, Factor e outras motos. No horário comercial, se faltar peça, o mecânico retira no fornecedor e vai até você."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mt-6 rounded-card border border-line bg-panel-2 p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
					className: "shrink-0 text-ok",
					size: 20
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Serviço particular e independente"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-mute",
					children: "Não temos vínculo com locadora de motos. Área base: 25 km a partir de Diadema. Fora disso, R$ 1,00 por km."
				})] })]
			})
		})
	] });
}
//#endregion
export { Home as component };
